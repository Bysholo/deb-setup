# SF-Mono-Nerd-Font

![SF Mono Nerd Font](Prompt.png)

## Apple's SF Mono font patched with [the Nerd Fonts patcher](https://github.com/ryanoasis/nerd-fonts#font-patcher)

Works on macOS, Linux and Windows.

## Install instructions (Mac)

```shell
brew tap epk/epk

# Homebrew < 2.6.0
brew cask install font-sf-mono-nerd-font

# Homebrew >= 2.6.0
brew install --cask font-sf-mono-nerd-font
```

This is intended for my personal use only.
